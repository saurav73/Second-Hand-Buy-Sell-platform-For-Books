package com.bookbridge.service;

import jakarta.mail.MessagingException;
import jakarta.mail.internet.MimeMessage;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;
import org.thymeleaf.TemplateEngine;
import org.thymeleaf.context.Context;

@Service
public class EmailService {

    @Autowired
    private JavaMailSender mailSender;
    
    @Autowired
    private TemplateEngine templateEngine;
    
    @Value("${spring.mail.username}")
    private String fromEmail;
    
    @Value("${app.base.url}")
    private String baseUrl;
    
    @Value("${app.frontend.url}")
    private String frontendUrl;

    @Async
    public void sendSimpleEmail(String to, String subject, String body) {
        SimpleMailMessage message = new SimpleMailMessage();
        message.setFrom(fromEmail);
        message.setTo(to);
        message.setSubject(subject);
        message.setText(body);
        
        mailSender.send(message);
    }

    @Async
    public void sendHtmlEmail(String to, String subject, String templateName, Context context) {
        try {
            MimeMessage message = mailSender.createMimeMessage();
            MimeMessageHelper helper = new MimeMessageHelper(message, true, "UTF-8");
            
            helper.setFrom(fromEmail);
            helper.setTo(to);
            helper.setSubject(subject);
            
            String htmlContent = templateEngine.process(templateName, context);
            helper.setText(htmlContent, true);
            
            mailSender.send(message);
        } catch (MessagingException e) {
            throw new RuntimeException("Failed to send email", e);
        }
    }

    @Async
    public void sendPasswordResetEmail(String to, String token) {
        Context context = new Context();
        context.setVariable("resetUrl", frontendUrl + "/reset-password?token=" + token);
        context.setVariable("supportEmail", fromEmail);
        
        sendHtmlEmail(to, "Reset Your BookBridge Password", "password-reset", context);
    }

    @Async
    public void sendWelcomeEmail(String to, String name) {
        Context context = new Context();
        context.setVariable("name", name);
        context.setVariable("loginUrl", frontendUrl + "/login");
        context.setVariable("supportEmail", fromEmail);
        
        sendHtmlEmail(to, "Welcome to BookBridge!", "welcome", context);
    }

    @Async
    public void sendOrderConfirmationEmail(String to, String name, String orderNumber) {
        Context context = new Context();
        context.setVariable("name", name);
        context.setVariable("orderNumber", orderNumber);
        context.setVariable("orderUrl", frontendUrl + "/orders/" + orderNumber);
        context.setVariable("supportEmail", fromEmail);
        
        sendHtmlEmail(to, "Your BookBridge Order Confirmation", "order-confirmation", context);
    }

    @Async
    public void sendPaymentConfirmationEmail(String to, String name, String orderNumber, String amount) {
        Context context = new Context();
        context.setVariable("name", name);
        context.setVariable("orderNumber", orderNumber);
        context.setVariable("amount", amount);
        context.setVariable("orderUrl", frontendUrl + "/orders/" + orderNumber);
        context.setVariable("supportEmail", fromEmail);
        
        sendHtmlEmail(to, "Payment Confirmation for Your BookBridge Order", "payment-confirmation", context);
    }
}
