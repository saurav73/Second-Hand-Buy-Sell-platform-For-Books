package com.bookbridge.config;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import java.io.File;

@Configuration
public class FileStorageConfig {

    @Value("${app.file.upload-dir}")
    private String uploadDir;

    @Bean
    public void createUploadDirectories() {
        createDirectory(uploadDir);
        createDirectory(uploadDir + "/profiles");
        createDirectory(uploadDir + "/id-cards");
        createDirectory(uploadDir + "/documents");
        createDirectory(uploadDir + "/books");
    }

    private void createDirectory(String directoryPath) {
        File directory = new File(directoryPath);
        if (!directory.exists()) {
            directory.mkdirs();
        }
    }
}
